﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BarretoSanteliz_5_MarcoSamuel
{
    internal class Reglas
    {
        public static void ReglasDelJuego()
        {


            Console.Clear(); // Limpiar la consola primero
            
            Console.SetCursorPosition(0, 0);
            Console.WriteLine("Hola jugadores/as bienvenidos.");
            
            Console.SetCursorPosition(0, 2);
            Console.WriteLine("Estas son las reglas del juego:");
            
            Console.SetCursorPosition(0, 4);
            Console.WriteLine("1. El juego se puede jugar entre 2 a 4 jugadores.");
            
            Console.SetCursorPosition(0, 6);
            Console.WriteLine("2. En el tablero existe 16 fichas de 4 colores diferentes:");
            
            Console.SetCursorPosition(4, 7);
            Console.WriteLine("4 rojos, 4 azules, 4 verdes, 4 amarillos");
            
            Console.SetCursorPosition(0, 9);
            Console.WriteLine("3. Cada jugador debe escoger cual de estas debe jugar");
            
            Console.SetCursorPosition(0, 11);
            Console.WriteLine("4. Una vez que elijan, al principio del juego los jugadores deben lanzar un dado para");
            
            Console.SetCursorPosition(4, 12);
            Console.WriteLine("sacar sus fichas, no podran sacar sus fichas hasta que tiren un 6");
            
            Console.SetCursorPosition(0, 14);
            Console.WriteLine("5. Luego de sacarlas deben recorrer todo el tablero hasta llegar a sus respectivas casillas de colores.");
           
            Console.SetCursorPosition(0, 16);
            Console.WriteLine("6. El jugador que lleve todas sus fichas a la 'zona segura' de sus colores correspondientes gana la partida.");

            Console.SetCursorPosition(0, 18);
            Console.WriteLine("Presiona Enter para volver al menú principal.");
            Console.ReadLine(); // Espera a que el usuario presione Enter antes de volver al menú

        

    } 
}
}
