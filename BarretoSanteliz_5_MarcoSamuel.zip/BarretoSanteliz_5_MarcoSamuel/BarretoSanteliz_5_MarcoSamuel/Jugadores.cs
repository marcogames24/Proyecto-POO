﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BarretoSanteliz_5_MarcoSamuel
{
    class Jugadores:Persona
    {

        public List<Ficha> Fichas { get; private set;}
        // Creamos una lista a la que llamamos Fichas, ya que de aqui seran las fichas o piezas
        // que usaremos en el ludo.Solo puede ser modificada dentro de la clase
        private int posicion; //variable privada que representa la posición actual del jugador en el tablero
        protected int turno; //variable protegida que indica el turno actual del jugador

        

        //Almacena las fichas del jugador. Solo puede ser modificada dentro de la clase Jugadores la lista

        public Jugadores(string nombre): base(nombre) 
        //Constructor que inicializa Fichas, posicion y turno.Llama al constructor de la clase base Persona.
        {

            Fichas = new List<Ficha>();  
                                         
            posicion = 0;               
            turno = 0;

            //posicion y turno son bariables privadas que se utilizan para indicar la posición actual
            //del jugador en el tablero(cuando mueve una de sus fichas respectivas) y turno que indica
            //el turno actual del jugador que este jugando en ese momento
        }
//        Constructor Jugadores(string nombre):

//Descripción: Inicializa una nueva instancia de la clase Jugadores.

//Función: Crea la lista Fichas y llama al constructor de la clase base Persona para inicializar el nombre del jugador.


        //public override void Jugar()
        //{
        //    Console.WriteLine($"{Nombre} está jugando"); //Como se menciono anteriormente el método override se utilizara
        //                                                 //para indicar cuál de los jugadores esta realizando su jugada en ese momento 
        //                                                 //y como serán 2 jugadores se estara sobreescribiendo con cada turno
        //}

        public void MoverFicha(int numeroDeCasillas) //Creamos ahora un método público llamada MoverFicha que contiene un parámetro
                                                     //llamado int numeroDeCasillas
        // Como estaremos jugando la partida se tiene que tener un registro de cuando el jugador mueve una de sus fichas
        // en el tablero y con ello incluye donde el jugador pone suu ficha una vez que termine de moverla.
        {

            posicion += numeroDeCasillas;
            Console.WriteLine($"{Nombre} ha movido una ficha {numeroDeCasillas}");
        
        }
    //Método MoverFicha(int numeroDeCasillas):

    //Descripción: Mueve una ficha del jugador.

    //Función: Incrementa la posición del jugador y muestra un mensaje en la consola.




    }
}
