﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BarretoSanteliz_5_MarcoSamuel
{
    internal class Menú
    {

        public static void InterfazMenu()
        {
            bool seguirJugando = true;//Creamos este bool seguirJugando porque si tras un tiempo uno de los jugadores decide ya no jugar
                                      //Podemos indicarle al sistema que nos retiramos, por eso al crear esta variable le decimos que sea true

            //seguirJugando: Esta variable booleana controla el bucle del menú principal.
            //Mientras sea true, el menú seguirá mostrando opciones.

            //MostrarMenu: Este método muestra el menú principal y permite al usuario seleccionar una opción:
            //jugar, mostrar las reglas o salir del juego.

            while (seguirJugando)
            {
                Console.Clear();
                Console.SetCursorPosition(30, 5);
                Console.WriteLine("Bienvenido a Ludo");
                Console.SetCursorPosition(30, 8);
                Console.WriteLine("Seleccione una opción: ");
                Console.SetCursorPosition(30, 9);
                Console.WriteLine("1) Jugar ");
                Console.SetCursorPosition(30, 10);
                Console.WriteLine("2) Mostrar Reglas ");
                Console.SetCursorPosition(30, 11);
                Console.WriteLine("3) Salir ");
                Console.SetCursorPosition(30, 12);
                Console.Write("Ingrese su opción: ");

                string opcionDelJugador = Console.ReadLine();
                Console.Clear();

                //Aqui nos permitira seleccionar las diferentes opciones que queramos realizar una vez que empiece el programa, 
                //opcion 1 nos permite entrar al juego y jugarlo con otra persona, 
                //opcion 2 nos permite visualizar las reglas del juego
                //opcion3 hace que decidamos retirarnos de la pantalla y termianr con el programa
                switch (opcionDelJugador)
                {
                    case "1":
                        Partida.IniciarPartida();
                        break;
                    case "2":
                        Reglas.ReglasDelJuego();
                        break;
                    case "3":
                        seguirJugando = false;
                        break;
                    default:
                        Console.SetCursorPosition(30, 13);
                        Console.WriteLine("La opción realizada es incorrecta, por favor intente de nuevo");
                        break;
                }
            }






        }
    }
}
