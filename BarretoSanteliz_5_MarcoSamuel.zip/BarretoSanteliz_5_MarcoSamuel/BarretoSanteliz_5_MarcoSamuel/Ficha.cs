﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BarretoSanteliz_5_MarcoSamuel
{
    class Ficha
    {
        //En esta clase maneja la existencia de las fichas en el juego , donde aqui reciben sus característicaa, al igual que su posición en el tablero

        public string Color { get; set; }
        public int Posicion { get; set; }
        public const int PosicionFinal = 55; // Ejemplo de posición final en un tablero de 15x15

        public Ficha(string color)
        {
            Color = color;
            Posicion = 0; // Posición inicial
        }

        // Método para verificar si está en la zona segura
        public bool EstaEnZonaSegura()
        {
            return Posicion >= PosicionFinal - 6; // Ejemplo de zona segura
        }



    }
}
