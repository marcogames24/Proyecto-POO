﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BarretoSanteliz_5_MarcoSamuel
{
    class Program
    {
        //Unidad 5
        //Entrega Documento pdf con enlace al archivo comprimido en.zip con el
        //proyecto del juego y el ejecutable en el campus virtual
        
        //1. Enunciado
        //Desarrolla un juego ya sea en la consola de Visual Studio o en Unity.El juego deberá incluir como mínimo
        //los siguientes conceptos aprendidos en la asignatura, aplicándolos de una manera útil para el
        //funcionamiento del juego:
        
        //1. Una función creada por vosostros que utilice al menos un parámetro
        
        //2. Una clase creada por vosotros que herede de una clase que no sea Monobehaviour
        
        //3. Una función virtual
        
        //4. Una función o variable estática.Variables privadas, públicas y protegidas.
        
        //5. Un constructor de una clase creada por vosotros.
        
        //6. Una lista
        
        //7. Un diccionario
        
        //Lo más importante en la valoración de la actividad será la implementación correcta de estos elementos,
        //aunque también se valorará el correcto funcionamiento del juego, su complejidad y su jugabilidad.
        static void Main(string[] args)
        {

           
            Menú.InterfazMenu(); //Aqui nos permite llamar a la clase Menú 

            



        }
    }
}
