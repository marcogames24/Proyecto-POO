﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BarretoSanteliz_5_MarcoSamuel
{
    class Partida
    {
        //Esta clase maneja la lógica principal del juego de Ludo,
        //incluyendo la inicialización de jugadores y el manejo de turnos.
        //Creamos un diccionario que se encargara de guardar a los jugadores que se registren en el sistema de juego
        //Dictionary<string, Jugadores> jugadores = new Dictionary<string, Jugadores>();
        //List<string> colores = new List<string> { "Rojo", "Azul" };
        //Creamos una lista a la que llamamos colores, en el tablero de juego como solo habra 2 jugadores pueden optar
        //por escoger que color de sus fichas escoger para jugar las cuales son: rojo y azul
        // Ingreso de los nombres de los jugadores

       
            public static void IniciarPartida()
            {



                Dictionary<string, Jugadores> jugadores = new Dictionary<string, Jugadores>();
                List<string> colores = new List<string> { "Rojo", "Azul" };

                for (int i = 0; i < 2; i++) //En este apartado ingresa los jugadores a la partida.
                {
                    Console.Write($"Ingrese el nombre del jugador {i + 1}: ");
                    string nombre = Console.ReadLine();
                    Jugadores jugador = new Jugadores(nombre);

                    string color = colores[i];
                    for (int j = 0; j < 4; j++)
                    {
                        jugador.Fichas.Add(new Ficha(color));
                    }

                    jugadores.Add(nombre, jugador);
                }

                Tablero tablero = new Tablero();

                bool juegoEnProgreso = true;
                int turnoActual = 0;

                while (juegoEnProgreso)
                {
                    Jugadores jugadorActual = jugadores.Values.ElementAt(turnoActual);

                    tablero.MostrarTablero(jugadores.Values.ElementAt(0), jugadores.Values.ElementAt(1));

                    Console.WriteLine($"Turno de {jugadorActual.Nombre} con fichas de color {jugadorActual.Fichas[0].Color}");
                    Console.WriteLine("Seleccione una ficha para mover (1-4):");
                    int indiceFicha = int.Parse(Console.ReadLine()) - 1;

                    Console.WriteLine("Presiona Enter para lanzar el dado...");
                    Console.ReadLine();

                //Como en algunos juegos de mesa creamos un nuevo elemento random llamado resultadoDado, cunado presionamos Enter cunado empieza el juego 
                //simula el movimiento de un dado cuyos valores estaran entre el 1 al 6 segun lo definimos anteriormente
                    Random random = new Random();
                    int resultadoDado = random.Next(1, 7);
                    Console.WriteLine($"Resultado del dado: {resultadoDado}");

                    tablero.MoverFicha(jugadorActual.Fichas[indiceFicha], resultadoDado);

                    // Mostrar el tablero actualizado
                    tablero.MostrarTablero(jugadores.Values.ElementAt(0), jugadores.Values.ElementAt(1));

                    turnoActual = (turnoActual + 1) % 2;

                    // Verificar si todas las fichas están en la zona segura
                    if (jugadorActual.Fichas.All(f => f.EstaEnZonaSegura()))
                    {
                        juegoEnProgreso = false;
                        Console.WriteLine($"El jugador {jugadorActual.Nombre} ha ganado el juego.");
                    }
                }
            }
        }

    }














