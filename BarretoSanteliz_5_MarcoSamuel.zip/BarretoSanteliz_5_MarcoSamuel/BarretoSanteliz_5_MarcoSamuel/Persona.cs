﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BarretoSanteliz_5_MarcoSamuel
{
    class Persona
    {
        //La clase Persona se utiliza como base para la clase Jugadores. Aquí definimos las propiedades
        //y métodos comunes que podrían ser utilizados por cualquier persona en el juego
        
        public string Nombre { get; set; } //Creamos una propiedad pública llamada Nombre, este se encargara de recibir
        //los nombres de los jugadores que ingresen en el juego 

        public Persona(string nombre) //Creamos un constructor de la clase Persona que se encargara de recibir el valor de Nombre
        {

            Nombre = nombre;  //Aqui indica que cuando se ingrese el nombre del usuario el atributo Nombre recibira los valores de 
                              //nombre que en este caso sera la identificación del jugador que ingrese al juego
        
        }
        public virtual void Jugar() 
        {
            Console.WriteLine($"{Nombre} está jugando"); //Método virtual que imprime un mensaje indicando que
            //la persona está jugando.Al ser virtual, permite ser sobrescrito en clases derivadas. Esto se debe a que
            //habra 2 personas jugando y para evitar realizar copias la función tantas veces usamos virtual.
                                                          
                                                         
        }
    }
}
