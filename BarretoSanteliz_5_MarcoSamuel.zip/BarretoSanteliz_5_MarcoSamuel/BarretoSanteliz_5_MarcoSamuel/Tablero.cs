﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BarretoSanteliz_5_MarcoSamuel
{
    class Tablero
    {
        //En la clase tablero se encargara de materializar a pantalla el tablero donde se realizara todo el juego 
        //donde incluira sus fichas con colores 

      
    
        private char[,] tablero;

        public Tablero()
        {
            tablero = new char[15, 15]; // Aumentamos el tamaño del tablero para mejor visualización
            InicializarTablero();
        }

        private void InicializarTablero()
        {
            // Inicializar con espacios vacíos
            for (int i = 0; i < 15; i++)
            {
                for (int j = 0; j < 15; j++)
                {
                    tablero[i, j] = ' ';
                }
            }

            // Dibujar las líneas del camino
            for (int i = 1; i < 14; i++)
            {
                tablero[7, i] = '-';
                tablero[i, 7] = '|';
            }

            // Dibujar las áreas de inicio
            for (int i = 1; i < 6; i++)
            {
                for (int j = 1; j < 6; j++)
                {
                    tablero[i, j] = 'R'; // Rojo
                    tablero[i, 14 - j] = 'B'; // Azul
                    tablero[14 - i, j] = 'G'; // Verde
                    tablero[14 - i, 14 - j] = 'Y'; // Amarillo
                }
            }

            // Dibujar las zonas seguras
            for (int i = 8; i < 13; i++)
            {
                tablero[6, i] = 'S'; // Segura para Rojo y Azul
                tablero[i, 6] = 'S'; // Segura para Rojo y Verde
            }

            for (int i = 2; i < 7; i++)
            {
                tablero[8, i] = 'S'; // Segura para Azul y Amarillo
                tablero[i, 8] = 'S'; // Segura para Verde y Amarillo
            }

            // Centro del tablero
            tablero[7, 7] = 'C';
        }

        public void MostrarTablero(Jugadores jugador1, Jugadores jugador2)//Esta funcion permitira visualizar el tablero en la pantalla
        {
            Console.Clear();
            // Dibujar fichas en el tablero
            foreach (var ficha in jugador1.Fichas)
            {
                tablero[ficha.Posicion / 15, ficha.Posicion % 15] = 'R'; // R para Rojo
            }
            foreach (var ficha in jugador2.Fichas)
            {
                tablero[ficha.Posicion / 15, ficha.Posicion % 15] = 'A'; // A para Azul
            }

            // Este for de aqui permitira mostrar el tablero en consola con colores
            for (int i = 0; i < 15; i++)
            {
                for (int j = 0; j < 15; j++)
                {
                    if (tablero[i, j] == 'R')
                    {
                        Console.ForegroundColor = ConsoleColor.Red;
                    }
                    else if (tablero[i, j] == 'A')
                    {
                        Console.ForegroundColor = ConsoleColor.Blue;
                    }
                    else if (tablero[i, j] == 'S')
                    {
                        Console.ForegroundColor = ConsoleColor.Green; // Verde para zona segura
                    }
                    else if (tablero[i, j] == 'B')
                    {
                        Console.ForegroundColor = ConsoleColor.Blue; // Azul
                    }
                    else if (tablero[i, j] == 'G')
                    {
                        Console.ForegroundColor = ConsoleColor.Green; // Verde
                    }
                    else if (tablero[i, j] == 'Y')
                    {
                        Console.ForegroundColor = ConsoleColor.Yellow; // Amarillo
                    }
                    else
                    {
                        Console.ForegroundColor = ConsoleColor.White;
                    }
                    Console.Write(tablero[i, j] + " ");
                }
                Console.WriteLine();
            }
            // Restablecer el color por defecto
            Console.ForegroundColor = ConsoleColor.White;
        }

        public void MoverFicha(Ficha ficha, int numeroDeCasillas) //Se encarga de el movimiento de las fichas en el tablero.
        {
            int nuevaPosicion = ficha.Posicion + numeroDeCasillas;
            if (nuevaPosicion > Ficha.PosicionFinal)
            {
                nuevaPosicion = Ficha.PosicionFinal;
            }
            ficha.Posicion = nuevaPosicion;
        }
    }

}















